<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://github.com/AceWinspire
 * @since      1.0.0
 *
 * @package    Qtest_builder
 * @subpackage Qtest_builder/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
